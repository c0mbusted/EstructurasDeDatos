long insertionSort(int arr[], int n, int desc);
