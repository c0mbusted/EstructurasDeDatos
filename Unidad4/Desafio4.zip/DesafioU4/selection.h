
long selectionSort(int arr[], int n, int desc);
