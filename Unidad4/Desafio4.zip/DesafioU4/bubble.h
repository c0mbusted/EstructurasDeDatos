
long bubbleSort(int arr[], int numelems, int desc);