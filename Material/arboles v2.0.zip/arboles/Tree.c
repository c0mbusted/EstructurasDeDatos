#include<stdlib.h>

typedef struct data{
	/*
	more attribs.
	*/
	int prior;
}Data;

typedef struct node{
	Data *data;
    struct node *left, *right;
}Node;

typedef struct tree{
	Node *root;
}Tree;

Data *createData(int prior /* more params... */){
	Data *d = (Data*)malloc(sizeof(Data));
	d->prior = prior;
	
	return d;
}

void freeData(Data *d){
	/*
	if heap, free...
	*/
	free(d);
}

Node *createNode(){
	Node *n = (Node*)malloc(sizeof(Node));
	n->left = NULL;
	n->right = NULL;
	n->data = NULL;
	return n;
}

void freeNode(Node *n){
	if(n->data != NULL) freeData(n->data);
	free(n);
}

Tree *createTree(){
	Tree *t = (Tree*)malloc(sizeof(Tree));
	t->root = NULL;
	return t;
}

void cleanTree(Node *n){
	if(n->left != NULL)
		cleanTree(n->left);
	if(n->right != NULL)
		cleanTree(n->right);
	freeNode(n);
}

void freeTree(Tree *t){
	if(t->root->left != NULL)
		cleanTree(t->root->left);
	if(t->root->right != NULL)
		cleanTree(t->root->right);
	free(t);
}

void orderInsert(Tree* t, Data *d){
	int prior = d->prior;
    Node *n = createNode();
	n->data = d;

    if (t->root == NULL)
        t->root = n;
    else{
        Node *last, *pass; //Last -> nodo padre | pass -> nodo de recorrido
        last = NULL;
        pass = t->root;
        while(pass != NULL){
            last = pass;
			int prior2 = pass->data->prior;
            if (prior < prior2)
                pass = pass->left;
            else
                pass = pass->right;
        }
        if (prior < last->data->prior)
            last->left = n;
        else
            last->right = n;
    }
}

void preOrder(Node *n){
    if (n != NULL){
        /*
		do for Node n
		*/
		printf("%i\n", n->data->prior);
		
        preOrder(n->left);
        preOrder(n->right);
    }
}

void inOrder(Node *n){
    if (n != NULL){
        inOrder(n->left);
		
		printf("%i\n", n->data->prior);
		/*
		do for Node n
		*/
        inOrder(n->right);
    }
}

void postOrder(Node *n){
    if (n != NULL){
        postOrder(n->left);
		postOrder(n->right);
		/*
		do for Node n
		*/
		printf("%i\n", n->data->prior);
    }
}


int esHoja(Node *n){
	if(n == NULL) return 0;
	return (n->right == NULL && n->left == NULL);
}



Node *buscar(Tree* T, int search){
	Node *busqueda = T->root; 
	
	if(busqueda == NULL) return NULL;
	
	while(!esHoja(busqueda)){
		if(search == busqueda->data->prior) return busqueda;
		
		if(search < busqueda->data->prior)
			busqueda = busqueda->left;
		else
			busqueda = busqueda->right;
	}
	
	return NULL;
}

Node *min(Tree* T){
	Node *busqueda = T->root; 
	
	if(busqueda == NULL) return NULL;
	
	while(!esHoja(busqueda))
		busqueda = busqueda->left;
	
	return busqueda;
}

Node *max(Tree* T){
	Node *busqueda = T->root; 
	
	if(busqueda == NULL) return NULL;
	
	while(!esHoja(busqueda))
		busqueda = busqueda->right;
	
	return busqueda;
}


