#include<stdio.h>
#include "Tree.c"

void contarPares(Node *n, int *cnt){
	if (n != NULL){
        contarPares(n->left, cnt);
		contarPares(n->right, cnt);
		/*
		do for Node n
		*/
		if(n->data->prior % 2 == 0) *cnt += 1;
    }
}

int main(){
	Tree *T = createTree();
	
	orderInsert(T, createData(100));
    orderInsert(T, createData(200));
	orderInsert(T, createData(9));
	orderInsert(T, createData(1));
	orderInsert(T, createData(1252));
	orderInsert(T, createData(2010));
	orderInsert(T, createData(120));
    

	Node *mi = min(T);
	Node *ma = max(T);
	printf("MAX: %i\n", ma->data->prior);
	printf("MIN: %i\n", mi->data->prior);
	
	
	int contador = 0;
	contarPares(T->root, &contador);
	printf("%i pares\n", contador);
	
	
	int s = 9;
	Node *bus = NULL;
	bus = buscar(T, s);
	if(bus != NULL)
		printf("%i Encontrado!\n", s);
	else
		printf("%i No se encontro\n", s);
	
	s = 101;
	bus = NULL;
	bus = buscar(T, 101);
	if(bus != NULL)
		printf("%i Encontrado!\n", s);
	else
		printf("%i No se encontro\n", s);
	
	printf("\n########\n");
	printf("Pre:");
	preOrder(T->root);
	
	printf("\n########\n");
	printf("In:");
	inOrder(T->root);
	
	printf("\n########\n");
	printf("Post:");
	postOrder(T->root);
	
	freeTree(T);
    return 0;
}