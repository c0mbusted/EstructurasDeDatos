#include <stdio.h>
#include <stdlib.h>

void llenarAleatorio(int *arreglo, int min, int max, int size){
	for(int k=0;k<size;k++)
		arreglo[k] = (rand() % (max + 1 - min)) + min;
}

void imprimirArreglo(int *arreglo, int size){
	for(int k=0;k<size;k++)
		printf("arreglo[%i] = %i\n", k, arreglo[k]);
}

int main(){
	int size = 1000000;
	//malloc asigna una cantidad de memoria dada por parámetro
	int* arr = (int*)malloc(sizeof(int) * size);
	//arr ocupa un tamaño de int * 1000000 = 4bytes * 1000000 = 4000000 = 4000 kb = 4 mb
	//arr es un arreglo de size elementos
	
	//Podemos reasignar memoría con realloc
	int agreguemos = 5;
	arr = (int*)realloc(arr, sizeof(int) * (size + agreguemos));
	//arr es un arreglo de size + agreguemos elementos, en este caso: 1m + 5
	
	int quitemos = 6;
	arr = (int*)realloc(arr, sizeof(int) * (size - quitemos));
	//arr es un arreglo de size - quitemos, en este caso: 1m - 5
	//WARNING: esta reasignación size no toma en cuenta el realloc anterior
	
	//La memoria dinámica al termino del programa, no se borrará de la memoria principal "RAM"
	//A esto se le llama memory leak, o fuga de memoria
	//debemos liberar
	free(arr);

	//Usanso arreglos
	//Es importante saber que no se puede calcular el tamaño de un arreglo de memoria dinámica
	size = 10;
	int* arr2 = (int*)malloc(sizeof(int) * size);
	llenarAleatorio(arr2, 1, 10, size);
	imprimirArreglo(arr2,size);
	arr2[9] = 100101;
	printf("\nImprimimos denuevo: \n");
	imprimirArreglo(arr2,size);
	//Fijarse que ya no usamos *arr[k] = nuevoValor
	//Si no que arr[k] = nuevoValor
	//Esto porque usamos memoria dinámica
	free(arr2);
	return 0;
}

