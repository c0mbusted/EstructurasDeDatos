#include <stdio.h>
#include <stdlib.h>

int **llenarAleatorio(int rows, int cols, int min, int max){
int **m = (int**)malloc(sizeof(int*) * rows);
	for(int k=0;k<rows;k++)
		m[k] = (int*)malloc(sizeof(int) * cols); //Cada fila de la mátriz es un puntero, asi que le asignamos valor



	for(int k=0;k<rows;k++)
		for(int j=0;j<cols;j++)
			m[k][j] = (rand() % (max + 1 - min)) + min;
	return m;
}

void limpiarMatriz(int** m, int rows){
	for(int k=0;k<rows;k++)
		free(m[0]); //Cada elemento es un puntero!!
	free(m);
}

void imprimirMatriz(int** m, int rows, int cols){
	for(int k=0;k<rows;k++){
		for(int i=0;i<cols;i++)
			printf("matriz[%i][%i] = %i\n", k, i, m[k][i]);
		printf("##########\n");
	}
}


int main(){
	int sizeRow = 10;
	int sizeCol = 5;
	int **matrix = llenarAleatorio(sizeRow, sizeCol, 1, 10);
	imprimirMatriz(matrix, sizeRow, sizeCol);
	limpiarMatriz(matrix, sizeRow);
	return 0;
}