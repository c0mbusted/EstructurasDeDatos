#include <stdio.h>
#include <stdlib.h>

typedef struct nombreEstructura{
	int foo;
	char *b;
}Alias;

void limpiarEstructura(Alias* e){
	free(e->b); //b es un puntero, hay que eliminarlo !!
	free(e);
}

Alias* crearEstructura(int a, char* b){
	Alias* e = (Alias*)malloc(sizeof(Alias));
	e->foo = a;
	e->b = b;
	return e;
}

int main(){
	Alias* estructura = crearEstructura(23, "algo");
	printf("foo de estructura: %i\n", estructura->foo);
	printf("b de estructura: %s\n", estructura->b);
	limpiarEstructura(estructura);
	return 0;
}







