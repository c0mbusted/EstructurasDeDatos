#include <stdio.h>
#include <stdlib.h>

typedef struct info{
	int dato;
}Info;

typedef struct node{
	struct node* next;
	Info* data;
}Node;

typedef struct list{
	int size;
	Node *first;
}List;

Info *createInfo(int n){
	Info *i = (Info*)malloc(sizeof(Info));
	i->dato = n;
	return i;
}

Node *createNode(){
	Node *n = (Node*)malloc(sizeof(Node));
	n->next = NULL;
	n->data = NULL;
	return n;
}

List *createList(){
	List *l = (List*)malloc(sizeof(List));
	l->size = 0;
	l->first = NULL;
	return l;
}

void append(List* l, int i){ //Función agregar elemento en la última pos.
Info *inf = createInfo(i); //Creamos una info
Node *n = createNode(); //Creamos un nodo
n->data = inf; //La data del nuevo nodo es inf
	if(l->size == 0) //Si el tamaño de la lista es 0, simplemente....
		l->first = n; //Es el primero de la lista
	else{ //De otra forma
		Node *aux = l->first; //Nodo auxiliar para recorrer
		for(int k=0;k<l->size-1;k++) //Recorremos hasta la penúltimo elemento
			aux = aux->next; //auxiliar pasa a ser el siguiente
		//Recorremos hasta el penúltimo, ya que en el último ciclo apuntamos al último elemento
		aux->next = n; //El último elemento ahora apunta al nuevo nodo, ahora nuevo nodo es el último
	}
l->size++; //Incrementamos el tamaño de la lista
}

void imprimir(List *l){
	Node *actual = l->first;
	for(int k=0;k<l->size;k++){
		printf("Valor: %i\n", actual->data->dato);
		actual = actual->next;
	}
}

void limpiarLista(List *l){ //Funcion para limpiar una lista
	if(l->size == 0) //Si la lista está vacía, simplemente....
		free(l); //Limpiamos
	else{ //De otro modo
		Node *actual = l->first;
		while(actual->next != NULL){ //Recorremos la lista hasta el penúltimo elemento (hasta el nodo que no tiene siguiente nulo)
			Node *del = actual; //El nodo a eliminar es el actual
			actual = actual->next; //Actual pasa al siguiente nodo
			free(del->data); //Eliminamos la data
			free(del); //Eliminamos el nodo
		}
		free(actual); //Libreamos el último
	}
}

int main(){
	List *l = createList();
	append(l, 3);
	append(l, 1);
	append(l, 4);
	append(l, 1);
	append(l, 5);
	append(l, 9);
	imprimir(l);
	limpiarLista(l);
	return 0;
}