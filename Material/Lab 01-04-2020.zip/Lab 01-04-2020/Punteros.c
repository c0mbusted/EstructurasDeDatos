#include <stdio.h>
#include <stdlib.h>

void cambioPorReferencia(int *referencia, int valor){
	*referencia = valor;
}

int main(){
	int a = 23;
	printf("### Que sucede con los estaticos? ###\n");
	printf("Contenido de a: %i\n", a);
	printf("Direccion de a: %i\n", &a);
	
	printf("\n\n### Que sucede con los estaticos? ###\n");
	int* ptr = &a;
	printf("Dir. memo. de a quien apunta de ptr: %i\n", ptr);
	printf("Dir. memo DEL ptr: %i\n", &ptr);
	printf("Contenido de a quien apunta ptr: %i\n", *ptr);
	printf("Cancelación de operador: %i", &*ptr);
	
	printf("\n\n### Que sucede con las referencias? ###\n");
	int b = 5;
	printf("b actual: %i\n", b);
	cambioPorReferencia(&b, 38597);
	printf("b actual: %i, cambio sin asignacion foo = var\n", b);
	return 0;
}