#include <stdio.h>
#include "List2C.c"

#define bool	int
#define true	1
#define false	0


void agregar(List *l){
	char rut[10];
	
	printf("RUT EMP: ");
	scanf("%s", rut);
	fflush(stdin);
	printf("\n");
	
	bool found = false;
	Node *n = l->first;
	
	for(int k=0;k<l->size;k++){
		if(strcmp(rut, n->data->rut) == 0 && n->data->que_soy == 0){ found = true; break; }
		n = n->next;
	}
	
	if(found){
		char rut_c[10];
		char nombre_c[20];
		char gen = 'x';
		int tipo;
		
		printf("Ingresa rut carga: ");
		scanf("%s", rut_c);
		fflush(stdin);
		
		printf("Ingresa nombre carga: ");
		scanf("%s", nombre_c);
		fflush(stdin);
		
		while(true){
			printf("Gen f/m: ");
			scanf("%c", &gen);
			fflush(stdin);
			if(gen == 'f' || gen == 'm') break;
			else printf("Elije bien asopao\n");
		}
		printf("\n");
		
		while(true){
			printf("Tipo 1 > conyugue | 2 > hijo: ");
			scanf("%i", &tipo);
			fflush(stdin);
			if(tipo == 1 || tipo == 2) break;
			else printf("Elije bien asopao\n");
		}
		
		printf("\n");
		add(l, createData("", "", "", -1, rut, rut_c, nombre_c, gen, tipo, 1), 0);
		printf("OK\n");
	}
	else
		printf("No se encontró el empleado\n");
}

void listarCargas(List *l, char *rut){
	Node *n = l->first;
	bool found = false;
	for(int k=0;k<l->size;k++){
		if(strcmp(rut, n->data->rut) == 0 && n->data->que_soy == 0){ found = true; break; }
		n = n->next;
	}
	
	if(found){
		printf("###########\n");
		printf("RUT:		%s \n", n->data->rut);
		printf("NOMBRE:		%s \n", n->data->nombre_emp);
		printf("CARGO:		%s \n", n->data->cargo_emp);
		printf("SUELDO B.:	%i \n", n->data->sbase);
		printf("###########\n\n");
		n = l->first;
		for(int k=0;k<l->size;k++){
			if(strcmp(n->data->rut_emp, rut) == 0 && n->data->que_soy == 1){
				printf("\tCarga\n");
				printf("\tRUT:		%s \n", n->data->rut_car);
				printf("\tNOMBRE:		%s \n", n->data->nombre_carga);
				printf("\tCARGO:		%c \n", n->data->gen);
				printf("\tTipo:		%i \n", n->data->tipo);
				printf("\t###########\n\n");
			}
			n = n->next;
		}
	}
	else
		printf("Empleado no encontrado\n");
}

long bono(List *l, char *rut){
	Node *n = l->first;
	bool found = false;
	for(int k=0;k<l->size;k++){
		if(strcmp(rut, n->data->rut) == 0 && n->data->que_soy == 0){ found = true; break; }
		n = n->next;
	}
	
	long bono = -1;
	if(found){
		bono = 0;
		n = l->first;
		for(int k=0;k<l->size;k++){
			if(strcmp(n->data->rut_emp, rut) == 0 && n->data->que_soy == 1)
				bono += (n->data->tipo == 1) ? 100000 : 50000;
			n = n->next;
		}
	}	
return bono;
}

int main(){	
	FILE *fp = fopen("file.txt", "r");
	List *l = createList();
	
	char c;
	int cntChr = 0, cntDato=0;
	
	char dato[20] = {'\0'};
	char rut[20] = {'\0'};
	char nombre_emp[20] = {'\0'};
	char cargo_emp[20] = {'\0'};

	while(true){
		c = fgetc(fp);
		//(c == ';') ? printf("\t") : printf("%c", c);
		if(c == '\n' || c == EOF){
			int sbase = atoi(dato);

			add(l, 
				createData(rut, nombre_emp, cargo_emp, sbase, "", "", "", '\0', -1, 0), 
			0);
			
			cntDato = cntChr = 0;
			for(int k=0;k<20;k++) rut[k] = cargo_emp[k] = nombre_emp[k] = dato[k] = '\0';
			if(c == EOF) break;
		}
		else if(c == ';'){
			if(cntDato == 0)
				strcpy(rut, dato);
			if(cntDato == 1)
				strcpy(nombre_emp, dato);
			if(cntDato == 2)
				strcpy(cargo_emp, dato);
			++cntDato;
			
			cntChr = 0;
			for(int k=0;k<20;k++) dato[k] = '\0'; 
		}
		else
			dato[cntChr++] = c;
	}
	fclose(fp); //Close file...
	
	Node *n = l->first;
	for(int k=0;k<l->size;k++){
		printf("###########\n");
		printf("RUT:		%s \n", n->data->rut);
		printf("NOMBRE:		%s \n", n->data->nombre_emp);
		printf("CARGO:		%s \n", n->data->cargo_emp);
		printf("SUELDO B.:	%i \n", n->data->sbase);
		printf("###########\n\n");
		n = n->next;
	}
	
	printf("HINT: equivocarse\n");
	agregar(l);
	printf("\n");

	printf("HINT: agregar a '1'\n");	
	agregar(l);
	printf("\n");

	printf("HINT: agregar a '1'\n");	
	agregar(l);
	printf("\n");
	
	listarCargas(l, "1");
	listarCargas(l, "2");
	
	
	freeList(l);
	//Bono...

	
	printf("\n\n####LIMPIANDO LISTA####\n");
	l = createList();

	add(l, createData("1", "juan", "boss", 1000, 	"", "", "", '\0', -1, 0) ,0);
	add(l, createData("", "", "", 0, 				"1", "123", "Carmela", 'f', 1, 1) ,0);
	add(l, createData("", "", "", 0, 				"1", "1234", "queso", 'm', 0, 1) ,0);
	add(l, createData("", "", "", 0, 				"1", "1232334", "jamon", 'm', 0, 1) ,0);
	add(l, createData("", "", "", 0, 				"1", "123234", "paella", 'f', 0, 1) ,0);
	printf("Bono: %ld\n", bono(l, "1"));
	
	add(l, createData("2", "juan2", "boss2", 1000, 	"", "", "", '\0', -1, 0) ,0);
	add(l, createData("", "", "", 0, 				"2", "12323", "coca cola", 'f', 1, 1) ,0);
	add(l, createData("", "", "", 0, 				"2", "1243234", "pepsi", 'm', 0, 1) ,0);	
	printf("Bono: %ld\n", bono(l, "2"));
	
	add(l, createData("3", "juan", "boss", 1000, "", "", "", '\0', -1, 0) ,0);
	printf("Bono: %ld\n", bono(l, "3"));
	
	printf("Bono: %ld\n", bono(l, "4"));
	freeList(l);
	return 0;
}