#include <stdlib.h>
#include <stdio.h>

#include "Pes.c"
#include "Ces.c"

void llenar(char **c, Pila *p, int pos){
	for(int k=p->tope-1; k>=0; k--)
		strcpy(c[pos+k], p->dato[k]);
}

void sort(char** vector){
    int iteracion = 0;
    int permutation = 1;
    int actual;
    while(permutation) {
        permutation = 0;
        iteracion ++;
        for (actual=0;actual<20-iteracion;actual++) {
            if (strcmp(vector[actual], vector[actual+1]) > 0){
                permutation = 1;
                // Intercambiamos los dos elementos
                char temp[1000];
				strcpy(temp, vector[actual]);
                strcpy(vector[actual], vector[actual+1]);
                strcpy(vector[actual+1], temp);
            }
        }
    }
}

int main(){
	Pila p1 = crearPila(), p2 = crearPila();
	char c[20][1000] = {'\0'};
	Cola q1 = crearCola();
	
	FILE *fp = fopen("archivo.txt", "r");
	
	char letra;
	char nombre[1000];
	int i = 0, cont = 0;
	while((letra = fgetc(fp))){
		if(letra == '\n' || letra == EOF){
			if(cont < 10)
				push_p(&p1, nombre);
			else
				push_p(&p2, nombre);
			cont++;
			i = 0;
			for(int j=0; j<1000;j++)
				nombre[j] = '\0';
			if(letra == EOF) break;
		}
		else
			nombre[i++] = letra;
	}
	fclose(fp);
	
	printPila(&p1);
	printf("\n\n##############\n");
	printPila(&p2);
	
	char *arr[20];
	for(int k=0;k<20;k++)
		arr[k] = c[k];
	
	llenar(arr, &p1, 0);
	llenar(arr, &p2, 10);
	
	sort(arr);
	
	printf("\n\n##############\n");
	for(int k=0;k<20;k++){
		printf("%s\n", arr[k]);
		push_c(&q1, arr[19-k]);
	}
	
	
	printf("\n\n##############\n\n");
	print_c(&q1);
	
	int o = -1;
	char s[1000];
	
	printf("SEARCH AND DEL: ");
	scanf("%s", s);

	for(int k=0;k<20;k++){
		if(strcmp(arr[k], s) == 0){
			printf("del[0/1]?\n");
			scanf("%i", &o);
			if(o){				
				for(int j=k;j<19;j++)
					strcpy(arr[j], arr[j+1]);
				
				for(int j=0; j<1000;j++)
					arr[19][j] = '\0';
				break;
			}
		}
	}
	
	if(o == -1)
		printf("\n######NOT FOUND##########\n");
	
	printf("\n\n##############\n");
	for(int k=0;k<20;k++)
		printf("%s\n", arr[k]);
	
	
	return 0;
}