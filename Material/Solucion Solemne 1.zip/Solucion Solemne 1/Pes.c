#include<conio.h>
#include<stdio.h>
#include<stdlib.h> 
#include<string.h>

#define max_p 10

typedef struct pila{
	int tope;
	char dato[max_p][1000];
}Pila;

int push_p(Pila* pila, char p[]){
	if(pila->tope < max_p){
		strcpy(pila->dato[pila->tope++],p);
		return 1;
	}
return 0;
}

int pop_p(Pila* pila){
	if(pila->tope-1 >= 0){
		pila->dato[--pila->tope];
		return 1;
	}
return 0;
}

Pila crearPila(){
	struct pila p = {0};
	return p;
}

int empty(Pila *p){
	return p->tope == 0;
}

void clear(Pila *p){
	while(!empty(p))
		pop_p(p);
}

void printPila(Pila *p){
	for(int k=p->tope-1;k>=0;k--)
		printf("%s\n",p->dato[k]);
}







