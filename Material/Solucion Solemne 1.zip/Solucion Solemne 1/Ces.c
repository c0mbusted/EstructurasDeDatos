#include<conio.h> 
#include<stdio.h> 
#include<stdlib.h> 
#define max_c 20

typedef struct cola{
	char datos[max_c][1000]; 
	int final;
}Cola;

Cola crearCola(){
	struct cola q = {0};
	return q;
}

int pop_c(Cola *q){
	if(q->final-1 >= 0){
		for(int k=0;k<q->final-1;k++)
			strcpy(q->datos[k], q->datos[k+1]);
		q->final--;
		return 1;
	}
return 0;
} 

int push_c(Cola *q, char n[]){
	if(q->final < max_c){
		strcpy(q->datos[q->final++], n);
		return 1;
	}
return 0;
}

void print_c(Cola *q){
	for(int k=0;k<q->final;k++)
		printf("%s\n", q->datos[k]);
}