#include <stdio.h>
#include <math.h>

void inception(int t, int p){
	long h = 60 * t * pow(16, p - 1);
	int a = (h/24)/365;
	int d = (h - ((a * 24) * 365)) / 24;
	h -= ((d * 24) + (a * 24 * 365));	
	printf("Estare %i años, %i dias, %i horas\n", a, d, h);
	int o;
	printf("Necesito entrar en otra profundidad? (1) Si\n");
	scanf("%i", &o);
	if(o == 1) inception(t, p + 1);
	printf("He salido de la profundidad %i\n", p);
}

int main(){
	int t;
	printf("Cuantas horas soñara?\n");
	scanf("%i", &t);
	inception(t, 1);
	printf("he desperado");
	return 0;
}


















/*
void f(Pila *p, int *c){
	if(empty(p)) return;
	if(value(p) % 2 == 0) *c += 1;
	pop_p(p);
	f(p, c);
}


int main(){
	Pila p = crearPila();
	int cont = 0;
	
	push_p(&p, 6); //1
	push_p(&p, 3);
	push_p(&p, 8); //2
	push_p(&p, 9);
	push_p(&p, 10); //3
	push_p(&p, 256); //4
	push_p(&p, 1023);
	push_p(&p, 771); //5
	push_p(&p, 3);
	push_p(&p, 99);
	
	f(&p, &cont);
	
	printf("La pila tiene: %i numeros pares", cont);
	

	return 0;
}*/