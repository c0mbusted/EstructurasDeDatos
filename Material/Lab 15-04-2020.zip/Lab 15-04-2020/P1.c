#include <stdio.h>
#include <conio.h>
#include <math.h>

#include "./libreria/Pes.c"
#include "./libreria/Ces.c"

int main(){
	int n = 12;
	Pila s = crearPila();
	Pila s2 = crearPila();
	for(int k=0;k<n;k++)
		if(empty(&s))
			push_p(&s, 1);
		else
			pop_p(&s);
		
	if(empty(&s))
		printf("%i par", n);
	else
		printf("%i !par", n);
	
	printf("\n");
	
	n = 13;
	for(int k=0;k<n;k++)
		if(empty(&s2))
			push_p(&s2, 1);
		else
			pop_p(&s2);
	
	if(empty(&s2))
		printf("%i par", n);
	else
		printf("%i !par", n);
	
	return 0;
}


















/*
void f(Pila *p, int *c){
	if(empty(p)) return;
	if(value(p) % 2 == 0) *c += 1;
	pop_p(p);
	f(p, c);
}


int main(){
	Pila p = crearPila();
	int cont = 0;
	
	push_p(&p, 6); //1
	push_p(&p, 3);
	push_p(&p, 8); //2
	push_p(&p, 9);
	push_p(&p, 10); //3
	push_p(&p, 256); //4
	push_p(&p, 1023);
	push_p(&p, 771); //5
	push_p(&p, 3);
	push_p(&p, 99);
	
	f(&p, &cont);
	
	printf("La pila tiene: %i numeros pares", cont);
	

	return 0;
}*/