#include<conio.h> 
#include<stdio.h> 
#include<stdlib.h> 

#define max 5 

typedef struct cola{
	int datos[max]; 
	int final;
}Cola;

Cola crearCola(){
	struct cola q = {0};
	return q;
}

int pop_c(Cola *q){
	if(q->final-1 >= 0){
		for(int k=0;k<q->final-1;k++)
			q->datos[k] = q->datos[k+1];
		q->final--;
		return 1;
	}
return 0;
} 

int push_c(Cola *q, int n){
	if(q->final < max){
		q->datos[q->final++] = n;
		return 1;
	}
return 0;
}

void print_c(Cola *q){
	printf("La cola:\n");
	for(int k=0;k<q->final;k++)
		printf("%i\n", q->datos[k]);
}

void sort(Pila *p){
	Pila s = crearPila(); //sorted
	Pila t = crearPila(); //transition
	push_p(&s, value(p)); //push in sort the stack
	pop_p(p); //pop stack
	while(!empty(p)){ //if not empty
		if(value(p) > value(&s)){ //if number higher than element of sort
			push_p(&s, value(p)); //push in sort the stack
			pop_p(p); //pop the stack
		}
		else{ //in other way
			while(value(p) < value(&s)){ //while sort element higher than stack
				push_p(&t, value(&s)); //push the sort in transition 
				pop_p(&s); //pop sort
			}
			push_p(&s, value(p)); //push sort the stack
			pop_p(p); //pop the stack
		}
		if(empty(p) && !empty(&t)) //if stack empty & transition not empty
			transfer(&t, p); //Pass all transition into stack
	}
	transfer(&s,p); //Pass all sort into stack
}