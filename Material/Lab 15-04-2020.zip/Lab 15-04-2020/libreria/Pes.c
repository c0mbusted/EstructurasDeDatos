#include<conio.h>
#include<stdio.h>
#include<stdlib.h> 

#define max_p 10

typedef struct pila{
	int tope;
	int dato[max_p];
}Pila;

int push_p(Pila* pila, int x){
	if(pila->tope+1 < max_p){
		pila->dato[pila->tope++] = x;
		return 1;
	}
return 0;
}

int pop_p(Pila* pila){
	if(pila->tope-1 >= 0){
		pila->dato[--pila->tope];
		return 1;
	}
return 0;
}

void print_p(Pila* p){
	printf("\nLa pila:\n");
	for(int k=p->tope-1;k>=0;k--)
		printf("%i\n", p->dato[k]);
}

Pila crearPila(){
	struct pila p = {0};
	return p;
}

int empty(Pila *p){
	return p->tope == 0;
}

void clear(Pila *p){
	while(!empty(p))
		pop_p(p);
}

int value(Pila *p){
	return p->dato[p->tope-1];
}

void transfer(Pila *original, Pila *dest){
	while(!empty(original)){
		push_p(dest, value(original));
		pop_p(original);
	}
}

