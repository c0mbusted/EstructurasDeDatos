#include <stdio.h>
#include <conio.h>
#include <math.h>

#include "./libreria/Pes.c"

void f(Pila *s, int *c){
	if(empty(s)) return;
	if(value(s) % 2 == 0) *c += 1;
	pop_p(s);
	f(s,c);
}

int main(){
	Pila s = crearPila();
	int cont = 0;
	
	push_p(&s, 2);
	push_p(&s, 5);
	push_p(&s, 1);
	push_p(&s, 4);
	push_p(&s, 1021);
	push_p(&s, 72);
	push_p(&s, -41);
	push_p(&s, 36);
	push_p(&s, -32);
	
	f(&s, &cont);
	printf("Hay %i pares en la pila", cont);
	
	return 0;
}


















/*
void f(Pila *p, int *c){
	if(empty(p)) return;
	if(value(p) % 2 == 0) *c += 1;
	pop_p(p);
	f(p, c);
}


int main(){
	Pila p = crearPila();
	int cont = 0;
	
	push_p(&p, 6); //1
	push_p(&p, 3);
	push_p(&p, 8); //2
	push_p(&p, 9);
	push_p(&p, 10); //3
	push_p(&p, 256); //4
	push_p(&p, 1023);
	push_p(&p, 771); //5
	push_p(&p, 3);
	push_p(&p, 99);
	
	f(&p, &cont);
	
	printf("La pila tiene: %i numeros pares", cont);
	

	return 0;
}*/