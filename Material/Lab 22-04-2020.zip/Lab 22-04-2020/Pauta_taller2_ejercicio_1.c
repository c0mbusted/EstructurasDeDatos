#include <stdio.h>

long p(int b, int e){
	return (e == 0) ? 1 : b * p(b, e - 1);
	/*
	Explicación....
	*/
}

long f(int n){
	return (n <=1 ) ? 1 : n * f(n - 1);
	/*
	Explicación....
	*/
}

double e(int x, int n){
	return p(x,n) / (double)f(n);
	/*
	Explicación....
	*/
}

int main(){
	printf("%.20lf", e(5,8));
	return 0;
}