#include <stdio.h>

long f(int n){
	return (n <= 1) ? 1 : n * f(n - 1); 
}

int c(int n, int k){
	return f(n) / (   f(n-k) * f(k)   );
}


void piramide(int hasta, int nivel, int k){
	printf("%i\t", c(nivel, k));
	if(nivel == hasta && k == hasta) return;
	if(nivel == k){
		printf("\n");
		k = -1;
		nivel++;
	}
	piramide(hasta, nivel, k+1);
}


int main(){
	piramide(10, 0, 0);
	return 0;
}