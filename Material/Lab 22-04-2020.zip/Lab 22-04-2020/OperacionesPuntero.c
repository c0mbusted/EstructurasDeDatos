#include <stdio.h>

void f1(int a, int b, double *r){
	*r = a + b;
}

void f2(int a, int b, double *r){
	*r = a - b;
}

void f3(int a, int b, double *r){
	*r = a * b;
}

void f4(int a, int b, double *r){
	if(b == 0) return;
	*r = a / (double)b;
}

int main(){
	int a = 3, b = 4;
	double r;
	
	f1(a,b,&r);
	printf("%lf\n", r);

	f2(a,b,&r);
	printf("%lf\n", r);
	
	f3(a,b,&r);
	printf("%lf\n", r);
	
	f4(a,b,&r);
	printf("%lf\n", r);

	
	
	return 0;
}