#include <stdio.h>

long p(int b, int e){
	return (e == 0) ? 1 : b * p(b, e - 1);
}

long f(int b, int e){
	return (e == 0) ? 1 : p(b, e) + f(b, e - 1);
}

int main(){
	printf("%lu", f(5,4));
	return 0;
}