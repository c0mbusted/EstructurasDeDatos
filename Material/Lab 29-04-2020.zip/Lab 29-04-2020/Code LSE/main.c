#include <stdio.h>
#include "List.c"

void printList(List *l){
	printf("\n####  LIST  ####\n    Size: %i\n-------------\n", l->size);
	Node *c = l->first;
	for(int k=0;k<l->size;k++){
		printf("    Pos: %i | Value: %i\n", k, c->data->d);
		c = c->next;
	}
	printf("####  END  ####\n");
}

int main(){
	List *l = createList();
	
	add(l, (Data*)createData(591), 0);
	add(l, (Data*)createData(124), 1);
	add(l, (Data*)createData(23421), 2);
	add(l, (Data*)createData(421), 4);
	add(l, (Data*)createData(2341), -1);
	add(l, (Data*)createData(2331), 100);
	
	printList(l);
	
	del(l, 100);
	printf("\n\n");
	printList(l);
	
	freeList(l);
	return 0;
}