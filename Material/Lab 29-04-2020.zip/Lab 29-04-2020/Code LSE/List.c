/*###############################
##                             ##
## LISTA SIMPLEMENTE ENLAZADA  ##
##                             ##
###############################*/
#include <stdlib.h>

typedef struct data{
	int d;
	/*
	atr1
	atr2 
	...
	*/
}Data;

Data* createData(int n/*, param1, param2, param3*/){
	Data* a = (Data*)malloc(sizeof(Data));
	a->d = n;
	/*
	a->attr1 = param1;
	a->attr2 = param2;
	a->attr3 = param3;
	*/
	return a;
}

void freeData(Data *data){
	/*
	If Data data has heap memory attributes, free here...
	HERE....
	*/
	
	//This at end
	free(data);
}



/*########################################
##                                      ##
##  NO CAMBIAR NADA DE AQUÍ PARA ABAJO  ##
##                                      ##
########################################*/

typedef struct node{
	Data *data;
	struct node *next;
}Node;

Node* createNode(){
	Node *a = (Node*)malloc(sizeof(Node));
	a->next = NULL;
	a->data = NULL;
	return a;
}

void freeNode(Node *n){
	if(n->data != NULL) freeData(n->data);
	free(n);
}

//LIST STUFF

typedef struct list{
	Node *first;
	int size;
}List;

List* createList(){
	List* a = (List*)malloc(sizeof(List));
	a->first = NULL;
	a->size = 0;
	return a;
}

void add(List* l, Data *d, int index){
	Node *n = createNode();
	n->data = d;
	if(l->size == 0)
		l->first = n;
	else if(index <= 0){
		n->next = l->first;
		l->first = n;
	}
	else if(index+1 >= l->size){
		Node *current = l->first;
		while(current->next != NULL)
			current = current->next;
		current->next = n;
	}
	else{
		Node *current = l->first;
		for(int k=0;k<index-1;k++)
			current = current->next;
		n->next = current->next;
		current->next = n;
	}
	l->size++;
}

void del(List* l, int index){
	if(l->size == 0) return;
	if(index <= 0){
		Node *tmp = l->first;
		if(l->size == 1)
			l->first = NULL;
		else
			l->first = l->first->next;
		freeNode(tmp);
	}
	else if(index > l->size){
		Node *current = l->first;
		for(int k=0;k<l->size-2;k++)
			current = current->next;
		freeNode(current->next);
		current->next = NULL;
	}
	else{
		Node *current = l->first;
		for(int k=0;k<index-1;k++)
			current = current->next;
		Node *temp = current->next;
		current->next = (current->next)->next;
		freeNode(temp);
	}
	l->size--;
}

void freeList(List *l){
	if(l->size != 0){
	Node *current = l->first;
		while(l->size != 0) del(l, 0);
	}
	free(l);
}