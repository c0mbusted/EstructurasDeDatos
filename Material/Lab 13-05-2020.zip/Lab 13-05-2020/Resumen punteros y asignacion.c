#include <stdio.h>
#include "List.c"

int main(){
	/*
	int elementos = a;
	int arr[elementos];
	int *arr = (int *)malloc(sizeof(int) * elementos);
	int n = +-X;
	arr = (int *)realloc(arr, sizeof(int) * (elementos + n));
	free(arr);
	*/
	-----
	
	int col=4, row=3;
	int **m = (int **)malloc(sizeof(int *) * row);
	for(int k=0;k<row,k++){
		m[k] = (int *)malloc(sizeof(int) * col);
		for(int j=0; j<col; j++)
			m[k][j] = rand();
	}
	
	Original:
	1,2,3,4
	5,6,7,8
	8,5,3,1
	
	m[1] = (int *)realloc(m[1], sizeof(int) * 2);
	
	1,2,3,4
	5,6     <----
	8,5,3,1
	
	
	for(int k: row)
		for(int j: col)
			printf("%i ", m[k][j]);
	
	CLARIFICAR:
	sizeof(heap) <--- mal
	
	return 0;
}