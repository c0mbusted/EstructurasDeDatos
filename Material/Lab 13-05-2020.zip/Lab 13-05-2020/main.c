#include <stdio.h>
#include "List2C.c"

void printLista(List *l){
	Node *aux = l->first;
	for(int k=0;k<l->size;k++){
		printf("%i, ", aux->data->d);
		aux = aux->next;
	}
	printf("\n");
}

int main(){
	List *L = createList();
	add(L, (Data*)createData(1), 0);
	printLista(L);
	add(L, (Data*)createData(2), 100);
	printLista(L);
	add(L, (Data*)createData(3), 0);
	printLista(L);
	add(L, (Data*)createData(4), 1000);
	printLista(L);
	add(L, (Data*)createData(5), 2);
	printLista(L);
	printf("#########\n");
	
	del(L, 0);
	printLista(L);
	del(L, L->size);
	printLista(L);
	del(L, 1);
	printLista(L);
	del(L, 0);
	printLista(L);
	del(L, 0);
	printLista(L);
	
	freeList(L);
	return 0;
	
	//3,1,5,2,4
	
}