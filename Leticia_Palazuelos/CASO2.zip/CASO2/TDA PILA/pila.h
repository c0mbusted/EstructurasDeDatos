#define MAX_PILA 11

typedef struct pila {
    int topeizq;
    int topeder;
    int A[MAX_PILA];
}Pila;

/*PROTOTIPOS*/

Pila crearPila();
int esVacia(Pila p);
int esLlena(Pila p); 
Pila push(Pila p, int elem);
Pila pop(Pila p);

//FUNCIONES

Pila crearPila() {
    Pila p; 
    p.topeizq=-1;
    p.topeder=12;
    return p;
}

int esVacia(Pila p) {
    if (p.topeizq==-1) {
        printf("\tPila vacia\n");
        return 1;
    } else {
        return 0;
    }
}

int esLlena(Pila p) {
    if (p.topeizq>= p.topeder) {
        printf("\nPila llena\n");
        return 1;
    } else {
        return 0;
    }
}

Pila push(Pila p, int elem) {
    if (!esLlena(p)) {
        p.topeizq++; //el tope es el indice que se va agregando
        printf("Tope izq=%d\n",p.topeizq);
        p.topeder--;
        printf("Tope der=%d\n",p.topeder);
        p.A[p.topeizq] = elem;
        p.A[p.topeder] = elem;
    }  
    return p;
}

Pila pop(Pila p) {
    if (!esVacia(p)) {
        p.topeizq--;
        p.topeder--;
    }
    return p;
}
